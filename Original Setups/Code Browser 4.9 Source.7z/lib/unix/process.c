// For portability issues, these functions are still written in C

#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>

typedef struct
{
	int	exit_code;
	pid_t	pid;
	int	stdin;
	int	stdout;
	int	stderr;
} Process;

void process_delete(Process* process);

static int process_start(	Process*	process, 
	char*	commandLine, 
	char*	directory,
	int	async)
{
	int	pid;
	int	stdin[2];
	int	stdout[2];
	int	stderr[2];
	char*	args[4];
	
	if( pipe(stdin) != 0 ) return 0;
	if( pipe(stdout) != 0 ) return 0;
	
	// Stderr will use same pipe as stout
	stderr[0] = dup (stdout[0]);
	stderr[1] = dup (stdout[1]);
	
	pid = fork();
	
	// Fork failed ?
	if( pid == -1 )
		return 0;
	
	// Child process ?
	if( pid == 0 )
	{
		// The stdin-pipe input becomes stdin
		close(0);
		dup(stdin[0]);
		close(stdin[0]);
		close(stdin[1]);
		
		// The stdout-pipe output becomes stdout
		close(1);
		dup(stdout[1]);
		close(stdout[0]);
		close(stdout[1]);
		
		// The stderr-pipe output becomes stderr
		close(2);
		dup(stderr[1]);
		close(stderr[0]);
		close(stderr[1]);
		
		// Empty directory means same as parent process
		if( directory[0] != 0 )
		{
			int res = chdir(directory);
			if( res != 0 )
				_exit (127);
		}
		
		args[0]	= "sh";
		args[1]	= "-c";
		args[2]	= commandLine;
		args[3]	= 0;
		execv("/bin/sh", args);
		_exit (127);
	}

	close(stdin[0]);
	close(stdin[1]);
	close(stderr[1]);
	close(stdout[1]);

	if( async )
	{
	  fcntl(stdout[0], F_SETFL, O_NONBLOCK);
	  fcntl(stderr[0], F_SETFL, O_NONBLOCK);
	}

	process->pid	= pid;
	process->stdout	= stdout[0];
	process->stderr	= stderr[0];
	return 1;
}

Process* process_create(	char*	commandLine, 
	char*	directory,
	int	async)
{
	Process* process;
	
	process = (Process*)malloc(sizeof(Process));
	
	// Initialize structure
	process->exit_code	= 0;
	process->stdin	= -1;
	process->stdout	= -1;
	process->stderr	= -1;

	// Create the process and start it
	if( process_start(	process, 
		commandLine, 
		directory, 
		async) )
	{
		return process;
	}
	else
	{
		process_delete(process);
		return NULL;
	}
}

void process_delete(Process* process)
{
	if( process->stdin != -1 )
		close(process->stdin);
	
	if( process->stdout != -1 )
		close(process->stdout);
	
	if( process->stderr != -1 )
		close(process->stderr);
	
	free(process);
}

void process_stop(Process* process)
{
	kill(process->pid, SIGTERM);
}

int process_stdout(Process* process)
{
	return process->stdout;
}

int process_stderr(Process* process)
{
	return process->stderr;
}

size_t process_read(Process* process, int fd, char* buffer, size_t size)
{
	return read(fd, buffer, size);
}

int process_exit_code(Process* process)
{
	return process->exit_code;
}

int process_is_running(Process* process)
{
	int status;
	int is_running = (waitpid(process->pid, &status, WNOHANG) == 0);
	if( !is_running )
		process->exit_code = WEXITSTATUS(status);
	return is_running;
}

void process_wait(Process* process)
{
	int status;
	waitpid(process->pid, &status, 0);
	process->exit_code = WEXITSTATUS(status);
}
