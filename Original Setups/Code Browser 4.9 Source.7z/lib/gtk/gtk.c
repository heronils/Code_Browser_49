// C functions to bypass zinc limitations
//
// * zinc does not implements floats and doubles yet
//   these functions convert floats to ints
// * zinc does not support variable argument number
// * Access to gtk structure attributes

#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <gtk/gtk.h>
#include "gdk/gdkprivate.h"
#include "gdk/gdkx.h"

///////////////////////////////////////////////////////////////////////////////
// Stubs for glib
///////////////////////////////////////////////////////////////////////////////

gpointer g_object_new_0 (GType t)
{
	return g_object_new(t, 0);
}

///////////////////////////////////////////////////////////////////////////////
//
// gdk events
//
///////////////////////////////////////////////////////////////////////////////

guint gdk_event_button_button (GdkEventButton* e)
{
	return e->button;
}

int gdk_event_button_get_x (GdkEventButton* e)
{
	return (int)e->x;
}

int gdk_event_button_get_y (GdkEventButton* e)
{
	return (int)e->y;
}

int gdk_event_motion_get_x (GdkEventMotion* e)
{
	return (int)e->x;
}

int gdk_event_motion_get_y (GdkEventMotion* e)
{
	return (int)e->y;
}

int gdk_event_scroll_get_x (GdkEventScroll* e)
{
	return (int)e->x;
}

int gdk_event_scroll_get_y (GdkEventScroll* e)
{
	return (int)e->y;
}


///////////////////////////////////////////////////////////////////////////////
//
// alignment
//
///////////////////////////////////////////////////////////////////////////////

void gtk_misc_set_align (GtkMisc *misc, gint xalign, gint yalign)
{
	gtk_misc_set_alignment (misc,
				((gfloat)xalign)/100.0,
				((gfloat)yalign)/100.0);
}

void gtk_misc_get_align (GtkMisc *misc, gint *xalign, gint *yalign)
{
	gfloat xa;
	gfloat ya;
	gtk_misc_get_alignment (misc, &xa, &ya);
	*xalign = (gint) (xa*100.0);
	*yalign = (gint) (ya*100.0);
}

///////////////////////////////////////////////////////////////////////////////
//
// Adjustment
//
///////////////////////////////////////////////////////////////////////////////

GtkObject* gtk_adjustment_new_int(
						 gint value,
						 gint lower,
						 gint upper,
						 gint step_increment,
						 gint page_increment,
						 gint page_size)
{
	return gtk_adjustment_new(
		(gdouble)value,
		(gdouble)lower,
		(gdouble)upper,
		(gdouble)step_increment,
		(gdouble)page_increment,
		(gdouble)page_size);
}
						 
void gtk_adjustment_clamp_page_int(GtkAdjustment *adjustment,
						 gint lower,
						 gint upper)
{
	gtk_adjustment_clamp_page(adjustment, (gdouble)lower, (gdouble)upper);
}

gint gtk_adjustment_get_value_int(GtkAdjustment *adjustment)
{
	return (gint)gtk_adjustment_get_value(adjustment);
}

void gtk_adjustment_set_value_int(GtkAdjustment *adjustment, gint value)
{
	gtk_adjustment_set_value(adjustment, (gdouble)value);
}

///////////////////////////////////////////////////////////////////////////////
//
// range
//
///////////////////////////////////////////////////////////////////////////////

void gtk_range_set_increments_int(GtkRange *range, gint step, gint page)
{
	gtk_range_set_increments(range, (gdouble)step, (gdouble)page);
}

void gtk_range_set_range_int(GtkRange *range, gint min, gint max)
{
	gtk_range_set_range (range, (gdouble)min, (gdouble)max);
}

void gtk_range_set_value_int(GtkRange *range, gint value)
{
	gtk_range_set_value(range, (gdouble)value);
}

gint gtk_range_get_value_int (GtkRange *range)
{
	return (gint)gtk_range_get_value(range);
}

///////////////////////////////////////////////////////////////////////////////
//
// access to widget attributes
//
///////////////////////////////////////////////////////////////////////////////

guint32 gtk_widget_get_flags (GtkWidget* w)
{
	return GTK_WIDGET_FLAGS (w);
}

void gtk_widget_set_flags (GtkWidget* w, guint flags)
{
	GTK_WIDGET_SET_FLAGS (w, flags);
}

void gtk_widget_unset_flags (GtkWidget* w, guint flags)
{
	GTK_WIDGET_UNSET_FLAGS (w, flags);
}

GdkWindow* gtk_widget_get_window (GtkWidget *widget)
{
  return widget->window;
}

GtkType* gtk_widget_type(GtkWidget* w)
{
	return (GtkType*)GTK_WIDGET_TYPE(w);
}

///////////////////////////////////////////////////////////////////////////////
//
// access to style attributes
//
///////////////////////////////////////////////////////////////////////////////

GdkColor* gtk_style_get_fg (GtkStyle* s, int state) { return &(s->fg[state]); }
GdkColor* gtk_style_get_bg (GtkStyle* s, int state) { return &(s->bg[state]); }
GdkColor* gtk_style_get_light (GtkStyle* s, int state) { return &(s->light[state]); }
GdkColor* gtk_style_get_dark (GtkStyle* s, int state) { return &(s->dark[state]); }
GdkColor* gtk_style_get_mid (GtkStyle* s, int state) { return &(s->mid[state]); }
GdkColor* gtk_style_get_text (GtkStyle* s, int state) { return &(s->text[state]); }
GdkColor* gtk_style_get_base (GtkStyle* s, int state) { return &(s->base[state]); }

GdkPixmap* gtk_style_get_pixmap (GtkStyle* s, int state) { return s->bg_pixmap[state]; }

///////////////////////////////////////////////////////////////////////////////
//
// message box
//
///////////////////////////////////////////////////////////////////////////////

GtkWidget* gtk_message_dialog_new_nofmt(GtkWindow      *parent,
                                        GtkDialogFlags  flags,
                                        GtkMessageType  type,
                                        GtkButtonsType  buttons,
                                        const gchar    *message)
{
	return gtk_message_dialog_new      (parent,
                                        flags,
                                        type,
                                        buttons,
                                        "%s",
                                        message);
}

///////////////////////////////////////////////////////////////////////////////
//
// File selector attributes
//
///////////////////////////////////////////////////////////////////////////////

GtkButton* gtk_file_selection_get_ok_button (GtkFileSelection* fs)
{
	return GTK_BUTTON (GTK_FILE_SELECTION (fs)->ok_button);
}

GtkButton* gtk_file_selection_get_cancel_button (GtkFileSelection* fs)
{
	return GTK_BUTTON (GTK_FILE_SELECTION (fs)->cancel_button);
}

GtkWidget* gtk_file_chooser_dialog_new_1(const gchar *title,
                                         GtkWindow *parent,
                                         GtkFileChooserAction action,
                                         const gchar *button_1,
                                         const gchar *button_2,
                                         const gchar *button_3,
                                         const gchar *button_4)
{
	return gtk_file_chooser_dialog_new(title,
                                       parent,
                                       action,
                                       button_1,
                                       button_2,
                                       button_3,
                                       button_4,
                                       (const gchar *)0);
}

void gtk_list_store_set_1(GtkListStore* store,GtkTreeIter* iter, int v1,gchar* v2,int v3)
{
	gtk_list_store_set(store, iter, v1, v2, v3);
}

GtkWidget* gtk_widget_new_0 (GtkType t)
{
	return gtk_widget_new(t, 0);
}

///////////////////////////////////////////////////////////////////////////////
//
// GDK
//
///////////////////////////////////////////////////////////////////////////////

// gdk_selection_owner_get cannot be used to check if a window from
// another process owns the selection (it fails with the xwindow -> gdkwindow
// conversion)
int check_selection_owner_get(GdkAtom atom)
{
	GdkDisplay *display;
	Atom xatom;
	Window xwindow;
	
	display = gdk_display_get_default();
	xatom = gdk_x11_atom_to_xatom_for_display(display, atom);
	xwindow = XGetSelectionOwner (gdk_display, xatom);

	return xwindow != None;	
}	

#define GTK_TYPE_CUSTOM                 (gtk_custom_get_type ())
#define GTK_CUSTOM(obj)                 (GTK_CHECK_CAST ((obj), GTK_TYPE_CUSTOM, GtkCustom))
#define GTK_CUSTOM_CLASS(klass)         (GTK_CHECK_CLASS_CAST ((klass), GTK_TYPE_CUSTOM, GtkCustomClass))
#define GTK_IS_CUSTOM(obj)              (GTK_CHECK_TYPE ((obj), GTK_TYPE_CUSTOM))
#define GTK_IS_CUSTOM_CLASS(klass)      (GTK_CHECK_CLASS_TYPE ((klass), GTK_TYPE_CUSTOM))
#define GTK_CUSTOM_GET_CLASS(obj)       (GTK_CHECK_GET_CLASS ((obj), GTK_TYPE_CUSTOM, GtkCustomClass))

typedef struct _GtkCustom        GtkCustom;
typedef struct _GtkCustomClass   GtkCustomClass;
typedef struct _GtkCustomChild    GtkCustomChild;

struct _GtkCustom
{
  GtkContainer container;
GList* children;
};

struct _GtkCustomClass
{
  GtkContainerClass parent_class;
};

struct _GtkCustomChild
{
  GtkWidget *widget;
};

GtkType    gtk_custom_get_type          (void) G_GNUC_CONST;
GtkWidget* gtk_custom_new               (void);

// custom container
// A simple container where size_request and size_allocate are left
// to the signal handlers

static void gtk_custom_class_init    (GtkCustomClass    *klass);
static void gtk_custom_init          (GtkCustom         *custom);
static void gtk_custom_realize       (GtkWidget        *widget);
static void gtk_custom_add           (GtkContainer     *container,
				     GtkWidget        *widget);
static void gtk_custom_remove        (GtkContainer     *container,
				     GtkWidget        *widget);
static void gtk_custom_forall        (GtkContainer     *container,
				     gboolean 	       include_internals,
				     GtkCallback       callback,
				     gpointer          callback_data);
static GtkType gtk_custom_child_type (GtkContainer     *container);


static GtkContainerClass *parent_class = NULL;

///////////////////////////////////////////////////////////////////////////////
// type access
///////////////////////////////////////////////////////////////////////////////
GtkType gtk_custom_get_type (void)
{
	static GtkType custom_type = 0;
	
	if (!custom_type)
	{
		static const GtkTypeInfo custom_info =
		{
			"GtkCustom",
			sizeof (GtkCustom),
			sizeof (GtkCustomClass),
			(GtkClassInitFunc) gtk_custom_class_init,
			(GtkObjectInitFunc) gtk_custom_init,
			/* reserved_1 */ NULL,
			/* reserved_2 */ NULL,
			(GtkClassInitFunc) NULL,
		};
		
		custom_type = gtk_type_unique (GTK_TYPE_CONTAINER, &custom_info);
	}
	
	return custom_type;
}

///////////////////////////////////////////////////////////////////////////////
// Class Initialization
///////////////////////////////////////////////////////////////////////////////
static void gtk_custom_class_init (GtkCustomClass *class)
{
	GtkObjectClass *object_class;
	GtkWidgetClass *widget_class;
	GtkContainerClass *container_class;
	
	object_class = (GtkObjectClass*) class;
	widget_class = (GtkWidgetClass*) class;
	container_class = (GtkContainerClass*) class;
	
	parent_class = gtk_type_class (GTK_TYPE_CONTAINER);
	
	widget_class->realize = gtk_custom_realize;
	
	container_class->add = gtk_custom_add;
	container_class->remove = gtk_custom_remove;
	container_class->forall = gtk_custom_forall;
	container_class->child_type = gtk_custom_child_type;
}

///////////////////////////////////////////////////////////////////////////////
// return child type
///////////////////////////////////////////////////////////////////////////////
static GtkType gtk_custom_child_type (GtkContainer *container)
{
	return GTK_TYPE_WIDGET;
}

///////////////////////////////////////////////////////////////////////////////
// initialize
///////////////////////////////////////////////////////////////////////////////
static void gtk_custom_init (GtkCustom *custom)
{
	GTK_WIDGET_UNSET_FLAGS (custom, GTK_NO_WINDOW);
	custom->children = NULL;
}

///////////////////////////////////////////////////////////////////////////////
// instance creation
///////////////////////////////////////////////////////////////////////////////
GtkWidget* gtk_custom_new (void)
{
	return GTK_WIDGET (gtk_type_new (GTK_TYPE_CUSTOM));
}

///////////////////////////////////////////////////////////////////////////////
// realize
///////////////////////////////////////////////////////////////////////////////
static void gtk_custom_realize (GtkWidget *widget)
{
	GdkWindowAttr attributes;
	gint attributes_mask;
	
	GTK_WIDGET_SET_FLAGS (widget, GTK_REALIZED);
	
	attributes.window_type = GDK_WINDOW_CHILD;
	attributes.x = widget->allocation.x;
	attributes.y = widget->allocation.y;
	attributes.width = widget->allocation.width;
	attributes.height = widget->allocation.height;
	attributes.wclass = GDK_INPUT_OUTPUT;
	attributes.visual = gtk_widget_get_visual (widget);
	attributes.colormap = gtk_widget_get_colormap (widget);
	attributes.event_mask = gtk_widget_get_events (widget);
	attributes.event_mask |= GDK_EXPOSURE_MASK | GDK_BUTTON_PRESS_MASK;
	
	attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP | GDK_WA_WMCLASS;
	
	widget->window = gdk_window_new (gtk_widget_get_parent_window (widget), &attributes, 
				   attributes_mask);
	gdk_window_set_user_data (widget->window, widget);
	
	widget->style = gtk_style_attach (widget->style, widget->window);
	gtk_style_set_background (widget->style, widget->window, GTK_STATE_NORMAL);
	gdk_window_set_back_pixmap (widget->window, NULL, FALSE);
}

///////////////////////////////////////////////////////////////////////////////
// add
///////////////////////////////////////////////////////////////////////////////
static void gtk_custom_add (GtkContainer *container, GtkWidget *widget)
{
	GtkCustom* custom;
	GtkCustomChild *child_info;
	
	g_return_if_fail (GTK_IS_CUSTOM (container));
	g_return_if_fail (GTK_IS_WIDGET (widget));
	
	custom = GTK_CUSTOM (container);
	
	child_info = g_new (GtkCustomChild, 1);
	child_info->widget = widget;
	
	gtk_widget_set_parent (widget, GTK_WIDGET (custom));
	
	custom->children = g_list_append (custom->children, child_info);
}

///////////////////////////////////////////////////////////////////////////////
// remove
///////////////////////////////////////////////////////////////////////////////
static void gtk_custom_remove (GtkContainer *container, GtkWidget *widget)
{
	GtkCustom *custom;
	GtkCustomChild *child;
	GList *children;
	
	custom = GTK_CUSTOM (container);
	
	children = custom->children;
	while (children)
	{
		child = children->data;
		
		if (child->widget == widget)
		{
			gboolean was_visible = GTK_WIDGET_VISIBLE (widget);
			
			gtk_widget_unparent (widget);
			
			custom->children = g_list_remove_link (custom->children, children);
			g_list_free (children);
			g_free (child);
			
			if (was_visible && GTK_WIDGET_VISIBLE (container))
			gtk_widget_queue_resize (GTK_WIDGET (container));
			
			break;
		}
		
		children = children->next;
	}
}

///////////////////////////////////////////////////////////////////////////////
// forall
///////////////////////////////////////////////////////////////////////////////
static void gtk_custom_forall (GtkContainer *container,
		  gboolean	include_internals,
		  GtkCallback   callback,
		  gpointer      callback_data)
{
	GtkCustom *custom;
	GtkCustomChild *child;
	GList *children;
	
	g_return_if_fail (callback != NULL);
	
	custom = GTK_CUSTOM (container);
	
	children = custom->children;
	while (children)
	{
		child = children->data;
		children = children->next;
		(* callback) (child->widget, callback_data);
	}
}

