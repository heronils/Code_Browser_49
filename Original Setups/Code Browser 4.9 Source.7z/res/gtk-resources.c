//
#include "code_browser_32.h"
#include "section.h"
#include "link.h"
#include "file.h"
#include "lock.h"

static char* _resources [] = 
{
	(char*)code_browser_32,
	(char*)folder,
	(char*)link,
	(char*)file,
	(char*)lock,
};

char* gtk_resources(int res)
{
  return _resources[res - 101];
}
