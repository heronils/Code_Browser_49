Code Browser 4.9

Introduction
============
Code Browser is a folding text editor for Linux and Windows, designed to 
hierarchically structure any kind of text file and expecially source code.
It makes navigation through source code faster and easier.

Features
========
- Sections to organize your source code
- Links to help navigation between files
- Special comment lines to give the source code a literate programming look
- Multiple files
- Multiples windows per file
- Several panes per window
- Smalltalk style browser
- Syntax highlighting for
	Assembler	ASP		Batches		C/C++
	C#		CSS		HTML		Java
	JSP		Makefile	Pascal		Perl
	PHP		Python		Ruby 		Sh
	SQL		TeX 		VB.Net		XML
- User definable syntax highlighting
- Unlimited undo/redo
- Word wrapping
- User defined tools
- User defined shortcuts
- Bookmarks
- Block indent/unindent
- Drop file to open
- Unicode: handle UTF-8 and UTF-16 files

License
=======
Code Browser is licensed under The GNU Public License.
See the file COPYING for more information.

Installation (Linux)
====================
Requisites:
* GTK+ >= 2.18

1. Extract the archive in a temporary folder.
2. Type 'cp -r usr /' as root, it will be installed under /usr/local/.
3. Type 'code-browser' to start it.

Installation from Source (Windows)
==================================
Requisites:
* Copper - http://tibleiz.net/copper/
* MinGW - You must have gcc and windres in your path.

Run the GNU make command from the root directory.

Installation from Source (Linux)
================================
Requisites:
* GTK+ >= 2.18
* Copper - http://tibleiz.net/copper/
* Ubuntu users: need build-essential and libgtk2.0-dev packages
	sudo apt-get install build-essential
	sudo apt-get install libgtk2.0-dev
* LLVM 3.2 if you're building on a 64 bit platform

Type 'make' to build the program on a Linux x86.
Type 'make LLVM=1' to build the program on a Linux x86-64.
Type 'make install' as root to install the program.

Changes
=======
Version 4.9 - 2014-04-05
	- Bug fix: one more v4 regression: relative indentation not saved correctly
	- Bug fix: crash with CSS syntax highlighting
	- Bug fix: Windows: a file could not be opened if it was open in 
	  write mode by another process

Version 4.8 - 2013-11-23
	- Bug fix: syntax highlighting could be broken with multiline styles

Version 4.7 - 2013-07-15
	- Generate an error if the function of a command does not exist
	- More command examples
	- Better loading of files with corrupted folding directives
	- Bug fix: memory leak with scripted commands
	- Bug fix: syntax highlighting of Ruby literal characters

Version 4.6 - 2013-01-27
	- Added scripting
	- Bug fix: GTK+: Tools shortcuts are lost when reloading settings
	- Bug fix: one more v4 regression: 'Replace All' could miss matches
	- Bug fix: one more v4 regression: 'Open' dialog does not always open

Version 4.5 - 2012-11-12
	- Bug fix: syntax highlighting of quoted strings in CSS
	- Bug fix: syntax highlighting of python doc-strings
	- Bug fix: Windows: leaks of handles with 'Find in Files'
	- Bug fix: crash with broken files using relative indentation
	
Version 4.4 - 2012-10-25
	- Bug fix: JSP syntax highlighting was still broken
	- Bug fix: "Open in New Tab" don't close the search window anymore
	- Bug fix: focus moving unexpectedly to first page in Page View
	- Bug fix: crash when deleting a section targeted by a link in another
	  view
	- Fixed regression: duplicates in find and replace history
	
Version 4.3 - 2012-09-20
	- Linux 64 bit version is back
	- Edit menu shortcuts from the option editor
	- Option editor isn't modal anymore (fine-tune your themes easily)
	- The 'escape' shortcut is now customizable (see Window menu)
	- Menu command to close a dialog or a window
	- Menu command to open a new file by selecting a filename first
	- Better positionning of cursor with kerning
	- Bug fix: handling of prototypes in configuration files could alter
	  wrong configurations
	
Version 4.2 - 2012-09-15
	- Linux version is back (32 bit x86 only)
	- Dedicated color for an inactive selected section or link
	- Syntax highlighting: preprocessor highlights only first word
	- Bug fix: crash when using the ALT+R shortcut with Replace All
	- Bug fix: syntax highlighting with Makefile multi-line variables were
	  broken
	
Version 4.1 - 2012-08-11
	- Option on languages to force the encoding of a file
	- Restored title of sections
	- Improved status bar
	- Bug fix: PHP, JSP and ASP syntax highlightings were broken
	- Bug fix: match whole word could miss words at end of line
	- Bug fix: possible corruption of the last line when folding a 
	  section in relative indentation mode
	- Bug fix: editing default language or system theme from the option
	  editor may propagate changes to other elements.
	- Bug fix: Enter command could stay disabled in page view

Version 4.0 - 2012-07-28
	- Folders are now called sections
	- Multiple fonts in styles
	- Sections and links are editable in-place
	- Quick new
	- Close buttons on tabs
	- Change the language from the menu
	- Change the theme from the menu
	- Graphical option editor
	- Quick switch proportional/monospaced font
	- No more title of sections to save space
	- No more extra-id-chars in language. It is computed automatically
	- No more variables in the configuration files (%(...)).
	

Author
======
Marc Kerbiquet, mkerbiquet@tibleiz.net

Contributors
============
Kristian Dupont
Holger Zwar
Gianni Trevisan
Damien Doiselet
Yannick Duchene
James Buren
Nils-Hero Lindemann
